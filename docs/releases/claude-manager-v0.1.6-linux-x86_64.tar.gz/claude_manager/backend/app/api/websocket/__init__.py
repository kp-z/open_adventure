"""WebSocket endpoints package"""
