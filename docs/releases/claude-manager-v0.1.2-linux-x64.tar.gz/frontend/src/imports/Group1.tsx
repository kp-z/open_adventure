import imgImage24 from "figma:asset/4344bceb6d2427d3cd55c95b42163277c8aa7d0b.png";
import imgImage25 from "figma:asset/c14446abc4ad8d4eea24260712b7ce264ed283de.png";
import imgImage26 from "figma:asset/d735af913d233f758c5f0d481dca63a9b92ec0c0.png";
import imgImage1 from "figma:asset/ac42bc2243842b144e86351c32dae20ee4a18bcc.png";
import imgImage2 from "figma:asset/d8633a922d9eb5694199bfc92ee060c5aefd88b8.png";
import imgImage3 from "figma:asset/8d472c9b56b8b8267d8b026701b86291d068a87e.png";
import imgImage4 from "figma:asset/3c8d1c0e302cb16330f866e30689725dbb18c9dd.png";
import imgImage5 from "figma:asset/4dd412ae78096ed1c65d9291d5d3d2aaf4f6f87f.png";
import imgImage6 from "figma:asset/e277891e17376e09628ddbb360f17a674731c086.png";
import imgImage7 from "figma:asset/5149d4b1c5f25e04c1e3f9c54c84aed74763a44f.png";
import imgImage8 from "figma:asset/991348e1c591f24014fcc2f1215d47984442d440.png";
import imgImage9 from "figma:asset/af8547f094edc2d42cc08992bfe7cde2c4d9b8f9.png";
import imgImage10 from "figma:asset/fe04fd1dd03795f07a2fc69969a713c66a0ac20e.png";
import imgImage11 from "figma:asset/7c79546d3547820114f44ab06e8a55747a95a194.png";
import imgImage12 from "figma:asset/7a0b2fe67db64f64d2d3932a3d88ca70ac2fdd7d.png";
import imgImage13 from "figma:asset/f5f48f7606ca5dd57d6c5450d7d6437d1341eaa3.png";
import imgAnimoji18 from "figma:asset/4621ffa2144b048c32f7522d72993079ecf38952.png";
import imgAnimoji19 from "figma:asset/61733b14a19b8402e7523f077ba583a47cc318e1.png";
import imgImage16 from "figma:asset/1a72cf1f6026d70b56d0ad3c2fdabe159c99426c.png";
import imgImage17 from "figma:asset/be5a988f576ada4703fa33dee18badaf10cc2b94.png";
import imgAnimoji22 from "figma:asset/096c0d610070f9a69f92320935e77e287a6f60ed.png";
import imgImage19 from "figma:asset/6b7f2cf7f00614cb21a702d255900aadeca89c7c.png";
import imgImage21 from "figma:asset/672b30ac5c86f71f548242d84cf12b66edf14967.png";
import imgImage22 from "figma:asset/0d7f7c41077c0199dcecb53aa21d2e063044dc86.png";
import imgImage29 from "figma:asset/2a56f81a0ca83361fb21c3791119fb27fa99852d.png";
import imgAnimoji27 from "figma:asset/b0df6376ce79cf0f6b114a0253cf2da3f5c719d0.png";
import imgImage31 from "figma:asset/9fb08455a811387d112cb2ad3d4dade66da096ab.png";
import imgAnimoji29 from "figma:asset/af1fbe1bddecd7507a420a38ecbd5a08e97b4bb9.png";
import imgAnimoji30 from "figma:asset/e9f72becc767e80ee23f6c6e34f58a5fd2e35f02.png";
import imgAnimoji31 from "figma:asset/e1e05ee67cbcc061991d7e2db95d635b0c483d8f.png";
import imgAnimoji32 from "figma:asset/ac0abfa4d002ea327b80815560f58ea06a108b82.png";
import imgAnimoji33 from "figma:asset/7247788bc5e5c9f311b9c353ede395dcd8f4efbe.png";
import imgAnimoji34 from "figma:asset/f2bcbebf9f36a89692721d661072f7ccfbb814a9.png";
import imgAnimoji35 from "figma:asset/d0da49421d652e99e275cb71d31afbca5687741b.png";
import imgAnimoji36 from "figma:asset/477fd381a18e461bed2e4d3cf4bf041f4b122d01.png";
import imgAnimoji37 from "figma:asset/b0e82944379e0777c2fac469238a1e726e45ac39.png";
import imgImage41 from "figma:asset/315977f6d0701f5092d840e0af9adc72d93b11d9.png";
import imgAnimoji39 from "figma:asset/ee9fa650623d47d20dfca397ff1b40c83a792f5c.png";
import imgAnimoji40 from "figma:asset/4cc6ee20fd37ea9fdf0f6a5e61b22c6e57d4a286.png";
import imgAnimoji41 from "figma:asset/496a78ffddc58d71935f74ccb60dc62ad3aa27d9.png";
import imgAnimoji42 from "figma:asset/c9f4c502729b8699f5e9c0438c436c132e613b48.png";
import imgImage46 from "figma:asset/13880e87361e3b22698ae93ea068d5e270abfc38.png";
import imgImage47 from "figma:asset/86b9844d29cdec218eff2674ae0be44fa504d64b.png";
import imgImage48 from "figma:asset/2270f57434ccc314b8396485f5f921be7e4220bc.png";
import imgImage49 from "figma:asset/91a39f17253a3e3b31549528c2aa4961a08accf0.png";
import imgImage50 from "figma:asset/07e0134a732978d05f8545c6c960640b20425585.png";
import imgImage51 from "figma:asset/8976dc71759d4c2196317fbff5577c5b27fb081b.png";
import imgImage52 from "figma:asset/6927a8b666aa085438b3fcacd6dcc63f40057b1b.png";
import imgImage53 from "figma:asset/c9486e5d7ea6c9f63698f044fb1548c55cbfae11.png";
import imgImage54 from "figma:asset/53b6d442189915e92279b0ff514f3359b3f77022.png";
import imgImage55 from "figma:asset/a533fddb9885a2ffd698f36b1fb597a6e2ae649d.png";
import imgImage56 from "figma:asset/44764c8f785923fa6d21c9efac971e3375027025.png";
import imgImage57 from "figma:asset/aecbb3f2a7d32a693cbe90ba1408f19d23e3c36b.png";
import imgImage58 from "figma:asset/9e90a48e93b36877d7ebdd167bb5056399774b2a.png";
import imgImage59 from "figma:asset/1f7e99d046b4fc88a5419f999763ce78d4de23f3.png";
import imgImage60 from "figma:asset/f2031e9d19d5e0b581d251542dc91ea97b06f6b9.png";
import imgImage61 from "figma:asset/9f652e886312cb6e75df1e1b83b5d4c5886ea92f.png";
import imgImage62 from "figma:asset/f4369dc00a69d3dc2efd756624bdd8c1be41529d.png";
import imgImage63 from "figma:asset/a721b72fbe7513ffe287ee502208beec93d34bd2.png";
import imgImage69 from "figma:asset/c793595cacc7dfbaa5c537ae8104cb24cebed8cd.png";
import imgImage70 from "figma:asset/1e791ae5fb313ac501ec9c80fece8f6e9e055cce.png";
import imgImage71 from "figma:asset/2a9f7cc92cd0668243cedb7996ce4db1d8b0c1f1.png";
import imgImage72 from "figma:asset/16991259f44b1ffc2a0800bf597f55f12e7fe0df.png";
import imgImage78 from "figma:asset/e26618a06c98c5095d0687f94e1c352ee451dda8.png";
import imgImage79 from "figma:asset/b8c3409024d832c1b27bd4f90abf86cdfbf74e2b.png";
import imgImage80 from "figma:asset/b478eafeaaf106973ea84d9cce9f815a4f87737e.png";
import imgImage81 from "figma:asset/17865ade453624740ddec8985c8277fe57fb2734.png";
import imgImage82 from "figma:asset/e8ecfcf95d0ce582d8e9cc19da26bef429ad152e.png";
import imgImage83 from "figma:asset/a55fd0068037e6b893c58c0a6993d81c2f76be75.png";
import imgAnimoji71 from "figma:asset/bd96610f26ac17eaecfd34849fe1c68e93201763.png";
import imgImage66 from "figma:asset/a489a31035d74963d1cfc09f0c07a373db5bcb82.png";
import imgImage67 from "figma:asset/90ad686357c4b7901760d69fc3a1b0621a5aec07.png";
import imgImage68 from "figma:asset/c8f0d6ed750df1a70067dff9b5d8ad08e7f83d7f.png";
import imgImage64 from "figma:asset/348f6644090e8228b194ed4c3f778ae7ceed81b8.png";
import imgImage73 from "figma:asset/6dcce3689206c89866d0759f008308563ab2d469.png";
import imgImage74 from "figma:asset/a683f67ffbb31fa7c7bceb60dc56d9c73ef88ac3.png";
import imgImage75 from "figma:asset/1f07c97ac96f16fb2fa2e58a76298b487beeb2cd.png";
import imgImage76 from "figma:asset/805202b94e339ccbab6272a246c1a35c82f7f2b0.png";
import imgAnimoji80 from "figma:asset/66a3a0d8c276e6579dc484c861ab4fa985ccdb5f.png";
import imgImage84 from "figma:asset/7f60804b2a1d2a21088a340cb5699b5aa2216a1c.png";
import imgAnimoji82 from "figma:asset/692f657f1863a585eb0de0c1319034fd3c6d735b.png";
import imgImage86 from "figma:asset/4b5f2ba4ca8dc8f99e9206a1ea5fcfca74c36666.png";
import imgImage87 from "figma:asset/5ca4bf6413c091b6eaad92a21dbb6c0228f11a80.png";
import imgImage88 from "figma:asset/a62add25b379946d8b32ecdda084eabb62da7ca6.png";
import imgImage89 from "figma:asset/948b2e72b5b2f769c3759c1c89db6ba231cf0689.png";
import imgImage90 from "figma:asset/fdd52b29aad55f442ae3198609cd9486960cc423.png";
import imgAnimoji88 from "figma:asset/14fb3b273336414f9909ac576b59cf123f073158.png";
import imgImage95 from "figma:asset/3c931aa14c8f064b529a82c179fc03fde9c7f978.png";
import imgImage96 from "figma:asset/109359a8eb45ae931794b859db19bdd26ec7b3b0.png";
import imgImage98 from "figma:asset/0f49c7a9f40bb52d375db32da3e273b36c165915.png";
import imgImage92 from "figma:asset/fdbc470cac8add50952baae908c8b33e13554a7d.png";
import imgImage93 from "figma:asset/83f86b4a93e045bad40d9789590f2a999e12d1fc.png";
import imgImage97 from "figma:asset/c4be6b066978e193c305d3c4aafe904b938ddc3a.png";
import imgImage99 from "figma:asset/0ebc22e1832a2358315b2e5e4be7d33e63243280.png";
import imgImage100 from "figma:asset/534629ea3033308c0d501f732cbb1d44855714f2.png";
import imgImage101 from "figma:asset/a015503c6d562deda11084bb6bb3b24fedf08b48.png";
import imgImage102 from "figma:asset/3f55e415b2efb7ef7bf31c1fffd82481e6227159.png";
import imgImage103 from "figma:asset/9c0cb4b2c35a6bd38cacbb57e60a7a518e6b8918.png";
import imgAnimoji100 from "figma:asset/288c259acd6d065c731d00d7c525f7959a633069.png";
import imgImage105 from "figma:asset/452199246d30b06027b0e79b6327fa458dfc48ac.png";
import imgAnimoji102 from "figma:asset/5d2b08327d30939cb9f15fe9463cfe2287fd4db2.png";
import imgImage107 from "figma:asset/1e2b80397d4e80be6f99b8423194154b6222d68a.png";
import imgAnimoji104 from "figma:asset/78e36caa4371923441216e79dd881d663e52a49e.png";
import imgAnimoji105 from "figma:asset/2a4c9ad076202344c30a1cbe512f3b28f49b1b6f.png";
import imgImage110 from "figma:asset/d6d03a72e8b28512e344894c1b736b8339a440b1.png";
import imgAnimoji107 from "figma:asset/d174ce965295cfba0c471998fcee8efca33fa42a.png";
import imgImage112 from "figma:asset/863303c288b3491a73b51bf7905d4d21376c6c95.png";
import imgAnimoji109 from "figma:asset/232744f55f5ab4415a748d1e5d1e875f4c7afcc8.png";
import imgAnimoji110 from "figma:asset/bb8d6e17209ef379c256c0d5de66b38f3903d5f2.png";
import imgAnimoji111 from "figma:asset/c46233ece0b5b78926fa8e990827b6224bd76f48.png";
import imgImage116 from "figma:asset/3cba96614bf97cd4a4fcf1fbdf2037d23cbcaeee.png";
import imgAnimoji113 from "figma:asset/71076a99a1d36cba0fafa94d8faaf864d26e19c1.png";
import imgAnimoji114 from "figma:asset/902a4da6d363e7419862c6cc52a7d0fc4fcda463.png";
import imgImage23 from "figma:asset/5366979e657fc9546d942d832169c93a4d9ce075.png";
import imgImage119 from "figma:asset/a9d97da28663a448f61778babcdda1a03acad136.png";
import imgImage94 from "figma:asset/770bfa0bb4cd93fe1295d21488eb2b215a36c3c6.png";

function Animoji1({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[160px] overflow-clip size-[128px] top-0"} data-name="animoji/2">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.34%_-4.79%_-2.44%]" data-name="image 24">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage24} />
      </div>
    </div>
  );
}

function Animoji2({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[320px] overflow-clip size-[128px] top-0"} data-name="animoji/3">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.83%_-5.66%_-2.83%]" data-name="image 25">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage25} />
      </div>
    </div>
  );
}

function Animoji3({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[480px] overflow-clip size-[128px] top-0"} data-name="animoji/4">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 26">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage26} />
      </div>
    </div>
  );
}

function Animoji4({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[640px] overflow-clip size-[128px] top-0"} data-name="animoji/5">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.44%_-4.79%_-2.44%]" data-name="image 1">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage1} />
      </div>
    </div>
  );
}

function Animoji5({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[800px] overflow-clip size-[128px] top-0"} data-name="animoji/6">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-1.56%_-9.38%_-22.66%_-14.84%]" data-name="image 2">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage2} />
      </div>
    </div>
  );
}

function Animoji6({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[960px] overflow-clip size-[128px] top-0"} data-name="animoji/7">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[4.98%_2.44%_0_2.54%]" data-name="image 3">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage3} />
      </div>
    </div>
  );
}

function Animoji7({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1120px] overflow-clip size-[128px] top-0"} data-name="animoji/8">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[5.57%_-1.27%_-8.01%_-1.17%]" data-name="image 4">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage4} />
      </div>
    </div>
  );
}

function Animoji8({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1280px] overflow-clip size-[128px] top-0"} data-name="animoji/9">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-2.34%_-6.25%_-10.16%_-6.25%]" data-name="image 5">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage5} />
      </div>
    </div>
  );
}

function Animoji9({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1440px] overflow-clip size-[128px] top-0"} data-name="animoji/10">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[4.69%_1.56%_-0.78%_1.56%]" data-name="image 6">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage6} />
      </div>
    </div>
  );
}

function Animoji10({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1600px] overflow-clip size-[128px] top-0"} data-name="animoji/11">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[4.88%_0_-4.88%_0]" data-name="image 7">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage7} />
      </div>
    </div>
  );
}

function Animoji11({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1760px] overflow-clip size-[128px] top-0"} data-name="animoji/12">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.42%_0_-3.42%_0]" data-name="image 8">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage8} />
      </div>
    </div>
  );
}

function Animoji12({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1920px] overflow-clip size-[128px] top-0"} data-name="animoji/13">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.17%_0_-1.17%_0]" data-name="image 9">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage9} />
      </div>
    </div>
  );
}

function Animoji13({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2080px] overflow-clip size-[128px] top-0"} data-name="animoji/14">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[2.44%_0_-2.44%_0]" data-name="image 10">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage10} />
      </div>
    </div>
  );
}

function Animoji14({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2240px] overflow-clip size-[128px] top-0"} data-name="animoji/15">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[7.91%_-3.22%_-14.26%_-3.13%]" data-name="image 11">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage11} />
      </div>
    </div>
  );
}

function Animoji15({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2400px] overflow-clip size-[128px] top-0"} data-name="animoji/16">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.22%_0_-3.22%_0]" data-name="image 12">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage12} />
      </div>
    </div>
  );
}

function Animoji16({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2560px] overflow-clip size-[128px] top-0"} data-name="animoji/17">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.91%_-5.47%_-7.81%_-5.47%]" data-name="image 13">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage13} />
      </div>
    </div>
  );
}

function Animoji17({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2720px] overflow-clip size-[128px] top-0"} data-name="animoji/18">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji18} />
    </div>
  );
}

function Animoji18({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2880px] overflow-clip size-[128px] top-0"} data-name="animoji/19">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji19} />
    </div>
  );
}

function Animoji19({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3040px] overflow-clip size-[128px] top-0"} data-name="animoji/20">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.34%_-4.69%_-2.34%]" data-name="image 16">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage16} />
      </div>
    </div>
  );
}

function Animoji20({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3200px] overflow-clip size-[128px] top-0"} data-name="animoji/21">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.81%_-7.62%_-3.81%]" data-name="image 17">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage17} />
      </div>
    </div>
  );
}

function Animoji21({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3360px] overflow-clip size-[128px] top-0"} data-name="animoji/22">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji22} />
    </div>
  );
}

function Animoji22({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3520px] overflow-clip size-[128px] top-0"} data-name="animoji/23">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.32%_1.66%_0_1.66%]" data-name="image 19">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage19} />
      </div>
    </div>
  );
}

function Animoji23({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3680px] overflow-clip size-[128px] top-0"} data-name="animoji/24">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[4%_1.95%_0_2.05%]" data-name="image 21">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage21} />
      </div>
    </div>
  );
}

function Animoji24({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3840px] overflow-clip size-[128px] top-0"} data-name="animoji/25">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[6.64%_3.32%_0_3.32%]" data-name="image 22">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage22} />
      </div>
    </div>
  );
}

function Animoji25({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-0 overflow-clip size-[128px] top-[176px]"} data-name="animoji/26">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[2.34%_0_0_0]" data-name="image 29">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[106.4%] left-[-2.34%] max-w-none top-0 w-[103.91%]" src={imgImage29} />
        </div>
      </div>
    </div>
  );
}

function Animoji26({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[160px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/27">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-9.37%] max-w-none size-[113.28%] top-0" src={imgAnimoji27} />
      </div>
    </div>
  );
}

function Animoji27({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[320px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/28">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.13%_-3.13%_-9.38%_-3.13%]" data-name="image 31">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage31} />
      </div>
    </div>
  );
}

function Animoji28({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[480px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/29">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-13.28%] max-w-none size-[125%] top-[-0.78%]" src={imgAnimoji29} />
      </div>
    </div>
  );
}

function Animoji29({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[640px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/30">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-8.59%] max-w-none size-[117.19%] top-0" src={imgAnimoji30} />
      </div>
    </div>
  );
}

function Animoji30({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[800px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/31">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-7.81%] max-w-none size-[114.84%] top-[-0.78%]" src={imgAnimoji31} />
      </div>
    </div>
  );
}

function Animoji31({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[960px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/32">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-4.69%] max-w-none size-[110.16%] top-[-5.47%]" src={imgAnimoji32} />
      </div>
    </div>
  );
}

function Animoji32({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1120px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/33">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-7.03%] max-w-none size-[113.28%] top-0" src={imgAnimoji33} />
      </div>
    </div>
  );
}

function Animoji33({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1280px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/34">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji34} />
    </div>
  );
}

function Animoji34({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1440px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/35">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-7.03%] max-w-none size-[117.97%] top-[-3.91%]" src={imgAnimoji35} />
      </div>
    </div>
  );
}

function Animoji35({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1600px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/36">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-3.91%] max-w-none size-[107.81%] top-0" src={imgAnimoji36} />
      </div>
    </div>
  );
}

function Animoji36({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1760px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/37">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-3.13%] max-w-none size-[105.47%] top-0" src={imgAnimoji37} />
      </div>
    </div>
  );
}

function Animoji37({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1920px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/38">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.56%_0_0_0]" data-name="image 41">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[119.05%] left-[-8.59%] max-w-none top-0 w-[117.19%]" src={imgImage41} />
        </div>
      </div>
    </div>
  );
}

function Animoji38({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2080px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/39">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-7.81%] max-w-none size-[121.87%] top-0" src={imgAnimoji39} />
      </div>
    </div>
  );
}

function Animoji39({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2240px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/40">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji40} />
    </div>
  );
}

function Animoji40({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2400px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/41">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji41} />
    </div>
  );
}

function Animoji41({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2560px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/42">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute left-[-2.34%] max-w-none size-[105.47%] top-0" src={imgAnimoji42} />
      </div>
    </div>
  );
}

function Animoji42({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2720px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/43">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.56%_-9.38%_-20.31%_-9.38%]" data-name="image 46">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage46} />
      </div>
    </div>
  );
}

function Animoji43({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2880px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/44">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-7.03%_-14.06%_-7.03%]" data-name="image 47">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage47} />
      </div>
    </div>
  );
}

function Animoji44({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3040px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/45">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-6.25%_-13.28%_-7.03%]" data-name="image 48">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage48} />
      </div>
    </div>
  );
}

function Animoji45({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3200px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/46">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.13%_-9.38%_-21.88%_-9.38%]" data-name="image 49">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage49} />
      </div>
    </div>
  );
}

function Animoji46({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3360px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/47">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-8.59%_-17.97%_-9.38%]" data-name="image 50">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage50} />
      </div>
    </div>
  );
}

function Animoji47({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3520px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/48">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[9.38%_-14.06%_-38.28%_-14.84%]" data-name="image 51">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage51} />
      </div>
    </div>
  );
}

function Animoji48({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3680px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/49">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-9.38%_-18.75%_-9.38%]" data-name="image 52">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage52} />
      </div>
    </div>
  );
}

function Animoji49({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3840px] overflow-clip size-[128px] top-[176px]"} data-name="animoji/50">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-7.81%_-16.41%_-8.59%]" data-name="image 53">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage53} />
      </div>
    </div>
  );
}

function Animoji50({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_96.77%_42.31%_0] overflow-clip"} data-name="animoji/51">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 54">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage54} />
      </div>
    </div>
  );
}

function Animoji51({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_92.74%_42.31%_4.03%] overflow-clip"} data-name="animoji/52">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-8.59%_-17.97%_-9.38%]" data-name="image 55">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage55} />
      </div>
    </div>
  );
}

function Animoji52({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_88.71%_42.31%_8.06%] overflow-clip"} data-name="animoji/53">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.91%_-8.59%_-21.88%_-9.38%]" data-name="image 56">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage56} />
      </div>
    </div>
  );
}

function Animoji53({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_84.68%_42.31%_12.1%] overflow-clip"} data-name="animoji/54">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-10.16%_-20.31%_-10.16%]" data-name="image 57">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage57} />
      </div>
    </div>
  );
}

function Animoji54({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_80.65%_42.31%_16.13%] overflow-clip"} data-name="animoji/55">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-10.16%_-20.31%_-10.16%]" data-name="image 58">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage58} />
      </div>
    </div>
  );
}

function Animoji55({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_76.61%_42.31%_20.16%] overflow-clip"} data-name="animoji/56">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.13%_-7.03%_-17.19%_-7.03%]" data-name="image 59">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage59} />
      </div>
    </div>
  );
}

function Animoji56({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_72.58%_42.31%_24.19%] overflow-clip"} data-name="animoji/57">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-22.66%_-46.88%_-24.22%]" data-name="image 60">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage60} />
      </div>
    </div>
  );
}

function Animoji57({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_68.55%_42.31%_28.23%] overflow-clip"} data-name="animoji/58">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.56%_-17.97%_-38.28%_-18.75%]" data-name="image 61">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage61} />
      </div>
    </div>
  );
}

function Animoji58({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_64.52%_42.31%_32.26%] overflow-clip"} data-name="animoji/59">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.56%_0_-1.56%_0]" data-name="image 62">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage62} />
      </div>
    </div>
  );
}

function Animoji59({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_60.48%_42.31%_36.29%] overflow-clip"} data-name="animoji/60">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[1.56%_-3.91%_-10.16%_-4.69%]" data-name="image 63">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage63} />
      </div>
    </div>
  );
}

function Animoji60({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_56.45%_42.31%_40.32%] overflow-clip"} data-name="animoji/61">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[6.25%_0_-5.47%_0.78%]" data-name="image 69">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage69} />
      </div>
    </div>
  );
}

function Animoji61({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_52.42%_42.31%_44.35%] overflow-clip"} data-name="animoji/62">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[4.69%_0_-3.91%_0.78%]" data-name="image 70">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage70} />
      </div>
    </div>
  );
}

function Animoji62({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_48.39%] overflow-clip"} data-name="animoji/63">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.91%_0_-3.91%_0]" data-name="image 71">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage71} />
      </div>
    </div>
  );
}

function Animoji63({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_44.35%_42.31%_52.42%] overflow-clip"} data-name="animoji/64">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[7.81%_0_-7.81%_0]" data-name="image 72">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage72} />
      </div>
    </div>
  );
}

function Animoji64({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_40.32%_42.31%_56.45%] overflow-clip"} data-name="animoji/65">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-5.47%_-10.16%_-4.69%]" data-name="image 78">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage78} />
      </div>
    </div>
  );
}

function Animoji65({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_36.29%_42.31%_60.48%] overflow-clip"} data-name="animoji/66">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-5.47%_-10.16%_-4.69%]" data-name="image 79">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage79} />
      </div>
    </div>
  );
}

function Animoji66({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_32.26%_42.31%_64.52%] overflow-clip"} data-name="animoji/67">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 80">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage80} />
      </div>
    </div>
  );
}

function Animoji67({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_28.23%_42.31%_68.55%] overflow-clip"} data-name="animoji/68">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-6.25%_-11.72%_-5.47%]" data-name="image 81">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage81} />
      </div>
    </div>
  );
}

function Animoji68({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_24.19%_42.31%_72.58%] overflow-clip"} data-name="animoji/69">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-7.03%_-13.28%_-6.25%]" data-name="image 82">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage82} />
      </div>
    </div>
  );
}

function Animoji69({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_20.16%_42.31%_76.61%] overflow-clip"} data-name="animoji/70">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 83">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage83} />
      </div>
    </div>
  );
}

function Animoji70({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_16.13%_42.31%_80.65%] overflow-clip"} data-name="animoji/71">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji71} />
    </div>
  );
}

function Animoji71({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_12.1%_42.31%_84.68%] overflow-clip"} data-name="animoji/72">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-1.56%_-5.47%_-9.38%_-5.47%]" data-name="image 66">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage66} />
      </div>
    </div>
  );
}

function Animoji72({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_8.06%_42.31%_88.71%] overflow-clip"} data-name="animoji/73">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 67">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage67} />
      </div>
    </div>
  );
}

function Animoji73({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[42.31%_4.03%_42.31%_92.74%] overflow-clip"} data-name="animoji/74">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-8.59%_-3.91%]" data-name="image 68">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage68} />
      </div>
    </div>
  );
}

function Animoji74({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3840px] overflow-clip size-[128px] top-[352px]"} data-name="animoji/75">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.13%_-6.25%_-9.38%_-6.25%]" data-name="image 64">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage64} />
      </div>
    </div>
  );
}

function Animoji75({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_96.77%_21.15%_0] overflow-clip"} data-name="animoji/76">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-1.56%_-3.13%_-1.56%]" data-name="image 73">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage73} />
      </div>
    </div>
  );
}

function Animoji76({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_92.74%_21.15%_4.03%] overflow-clip"} data-name="animoji/77">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 74">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage74} />
      </div>
    </div>
  );
}

function Animoji77({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_88.71%_21.15%_8.06%] overflow-clip"} data-name="animoji/78">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-8.59%_-3.91%]" data-name="image 75">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage75} />
      </div>
    </div>
  );
}

function Animoji78({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_84.68%_21.15%_12.1%] overflow-clip"} data-name="animoji/79">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 76">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage76} />
      </div>
    </div>
  );
}

function Animoji79({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_80.65%_21.15%_16.13%] overflow-clip"} data-name="animoji/80">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji80} />
    </div>
  );
}

function Animoji80({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_76.61%_21.15%_20.16%] overflow-clip"} data-name="animoji/81">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-6.25%_-12.5%_-6.25%]" data-name="image 84">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage84} />
      </div>
    </div>
  );
}

function Animoji81({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_72.58%_21.15%_24.19%] overflow-clip"} data-name="animoji/82">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji82} />
    </div>
  );
}

function Animoji82({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_68.55%_21.15%_28.23%] overflow-clip"} data-name="animoji/83">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[3.13%_-3.91%_-10.16%_-3.13%]" data-name="image 86">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage86} />
      </div>
    </div>
  );
}

function Animoji83({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_64.52%_21.15%_32.26%] overflow-clip"} data-name="animoji/84">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 87">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage87} />
      </div>
    </div>
  );
}

function Animoji84({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_60.48%_21.15%_36.29%] overflow-clip"} data-name="animoji/85">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-7.03%_-14.06%_-7.03%]" data-name="image 88">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage88} />
      </div>
    </div>
  );
}

function Animoji85({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_56.45%_21.15%_40.32%] overflow-clip"} data-name="animoji/86">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.13%_-5.47%_-7.81%_-5.47%]" data-name="image 89">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage89} />
      </div>
    </div>
  );
}

function Animoji86({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_52.42%_21.15%_44.35%] overflow-clip"} data-name="animoji/87">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.91%_-4.69%_-3.91%_-3.13%]" data-name="image 90">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage90} />
      </div>
    </div>
  );
}

function Animoji87({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_48.39%_21.15%_48.39%] overflow-clip"} data-name="animoji/88">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji88} />
    </div>
  );
}

function Animoji88({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_44.35%_21.15%_52.42%] overflow-clip"} data-name="animoji/89">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-30.47%_-60.16%_-29.69%]" data-name="image 95">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage95} />
      </div>
    </div>
  );
}

function Animoji89({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_40.32%_21.15%_56.45%] overflow-clip"} data-name="animoji/90">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[10.94%_-18.75%_-47.66%_-17.97%]" data-name="image 96">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage96} />
      </div>
    </div>
  );
}

function Animoji90({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_36.29%_21.15%_60.48%] overflow-clip"} data-name="animoji/91">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[6.25%_-28.91%_-57.81%_-22.66%]" data-name="image 98">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage98} />
      </div>
    </div>
  );
}

function Animoji91({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_32.26%_21.15%_64.52%] overflow-clip"} data-name="animoji/92">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-13.28%_-7.03%_0_-6.25%]" data-name="image 92">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage92} />
      </div>
    </div>
  );
}

function Animoji92({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_28.23%_21.15%_68.55%] overflow-clip"} data-name="animoji/93">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.91%_-6.25%_-8.59%_-6.25%]" data-name="image 93">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage93} />
      </div>
    </div>
  );
}

function Animoji93({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_20.16%_21.15%_76.61%] overflow-clip"} data-name="animoji/94">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-3.13%_-1.56%_0_-1.56%]" data-name="image 97">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage97} />
      </div>
    </div>
  );
}

function Animoji94({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_16.13%_21.15%_80.65%] overflow-clip"} data-name="animoji/95">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 99">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage99} />
      </div>
    </div>
  );
}

function Animoji95({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_12.1%_21.15%_84.68%] overflow-clip"} data-name="animoji/96">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 100">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage100} />
      </div>
    </div>
  );
}

function Animoji96({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_8.06%_21.15%_88.71%] overflow-clip"} data-name="animoji/97">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-5.47%_-10.16%_-4.69%]" data-name="image 101">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage101} />
      </div>
    </div>
  );
}

function Animoji97({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_4.03%_21.15%_92.74%] overflow-clip"} data-name="animoji/98">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-8.59%_-17.19%_-8.59%]" data-name="image 102">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage102} />
      </div>
    </div>
  );
}

function Animoji98({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[3840px] overflow-clip size-[128px] top-[528px]"} data-name="animoji/99">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-4.69%_-9.38%_-4.69%]" data-name="image 103">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage103} />
      </div>
    </div>
  );
}

function Animoji99({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-0 overflow-clip size-[128px] top-[704px]"} data-name="animoji/100">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji100} />
    </div>
  );
}

function Animoji100({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[160px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/101">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-7.81%]" data-name="image 105">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage105} />
      </div>
    </div>
  );
}

function Animoji101({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[320px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/102">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji102} />
    </div>
  );
}

function Animoji102({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[480px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/103">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-6.25%_-11.72%_-5.47%]" data-name="image 107">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage107} />
      </div>
    </div>
  );
}

function Animoji103({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[640px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/104">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji104} />
    </div>
  );
}

function Animoji104({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[800px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/105">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji105} />
    </div>
  );
}

function Animoji105({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[960px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/106">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[-2.34%_-4.69%_-6.25%_-3.91%]" data-name="image 110">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage110} />
      </div>
    </div>
  );
}

function Animoji106({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1120px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/107">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji107} />
    </div>
  );
}

function Animoji107({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1280px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/108">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 112">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage112} />
      </div>
    </div>
  );
}

function Animoji108({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1440px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/109">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji109} />
    </div>
  );
}

function Animoji109({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1600px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/110">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji110} />
    </div>
  );
}

function Animoji110({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1760px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/111">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji111} />
    </div>
  );
}

function Animoji111({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[1920px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/112">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-3.91%_-7.81%_-3.91%]" data-name="image 116">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage116} />
      </div>
    </div>
  );
}

function Animoji112({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2080px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/113">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji113} />
    </div>
  );
}

function Animoji113({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2240px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/114">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgAnimoji114} />
    </div>
  );
}

function Animoji({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-0 overflow-clip size-[128px] top-0"} data-name="animoji/1">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.05%_-4.1%_-2.05%]" data-name="image 23">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage23} />
      </div>
    </div>
  );
}

function Animoji114({ className }: { className?: string }) {
  return (
    <div className={className || "absolute left-[2400px] overflow-clip size-[128px] top-[704px]"} data-name="animoji/115">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[7.03%_0_-7.03%_0]" data-name="image 119">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage119} />
      </div>
    </div>
  );
}

function Animoji115({ className }: { className?: string }) {
  return (
    <div className={className || "absolute inset-[63.46%_24.19%_21.15%_72.58%] overflow-clip"} data-name="animoji/116">
      <div className="absolute bg-[#b190b6] inset-0" data-name="bg color" />
      <div className="absolute inset-[0_-2.34%_-4.69%_-2.34%]" data-name="image 94">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage94} />
      </div>
    </div>
  );
}

export default function Group() {
  return (
    <div className="relative size-full">
      <Animoji1 />
      <Animoji2 />
      <Animoji3 />
      <Animoji4 />
      <Animoji5 />
      <Animoji6 />
      <Animoji7 />
      <Animoji8 />
      <Animoji9 />
      <Animoji10 />
      <Animoji11 />
      <Animoji12 />
      <Animoji13 />
      <Animoji14 />
      <Animoji15 />
      <Animoji16 />
      <Animoji17 />
      <Animoji18 />
      <Animoji19 />
      <Animoji20 />
      <Animoji21 />
      <Animoji22 />
      <Animoji23 />
      <Animoji24 />
      <Animoji25 />
      <Animoji26 />
      <Animoji27 />
      <Animoji28 />
      <Animoji29 />
      <Animoji30 />
      <Animoji31 />
      <Animoji32 />
      <Animoji33 />
      <Animoji34 />
      <Animoji35 />
      <Animoji36 />
      <Animoji37 />
      <Animoji38 />
      <Animoji39 />
      <Animoji40 />
      <Animoji41 />
      <Animoji42 />
      <Animoji43 />
      <Animoji44 />
      <Animoji45 />
      <Animoji46 />
      <Animoji47 />
      <Animoji48 />
      <Animoji49 />
      <Animoji50 />
      <Animoji51 />
      <Animoji52 />
      <Animoji53 />
      <Animoji54 />
      <Animoji55 />
      <Animoji56 />
      <Animoji57 />
      <Animoji58 />
      <Animoji59 />
      <Animoji60 />
      <Animoji61 />
      <Animoji62 />
      <Animoji63 />
      <Animoji64 />
      <Animoji65 />
      <Animoji66 />
      <Animoji67 />
      <Animoji68 />
      <Animoji69 />
      <Animoji70 />
      <Animoji71 />
      <Animoji72 />
      <Animoji73 />
      <Animoji74 />
      <Animoji75 />
      <Animoji76 />
      <Animoji77 />
      <Animoji78 />
      <Animoji79 />
      <Animoji80 />
      <Animoji81 />
      <Animoji82 />
      <Animoji83 />
      <Animoji84 />
      <Animoji85 />
      <Animoji86 />
      <Animoji87 />
      <Animoji88 />
      <Animoji89 />
      <Animoji90 />
      <Animoji91 />
      <Animoji92 />
      <Animoji93 />
      <Animoji94 />
      <Animoji95 />
      <Animoji96 />
      <Animoji97 />
      <Animoji98 />
      <Animoji99 />
      <Animoji100 />
      <Animoji101 />
      <Animoji102 />
      <Animoji103 />
      <Animoji104 />
      <Animoji105 />
      <Animoji106 />
      <Animoji107 />
      <Animoji108 />
      <Animoji109 />
      <Animoji110 />
      <Animoji111 />
      <Animoji112 />
      <Animoji113 />
      <Animoji />
      <Animoji114 />
      <Animoji115 />
    </div>
  );
}