import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <img src="../image/mlrs4quv-2dx0za5.png" className={styles.referNcia} />
  );
}

export default Component;
