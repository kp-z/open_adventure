"""
Tests for services
"""
