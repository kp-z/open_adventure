/**
 * API 配置
 * 统一管理所有 API 和 WebSocket 地址
 */

// 从环境变量读取配置，如果没有则使用默认值
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api';
const WS_BASE_URL = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000/api';

// 提取 HTTP 基础 URL（不含 /api 后缀）
const getHttpBaseUrl = () => {
  return API_BASE_URL.replace(/\/api$/, '');
};

// 提取 WebSocket 基础 URL（不含 /api 后缀）
const getWsBaseUrl = () => {
  return WS_BASE_URL.replace(/\/api$/, '');
};

export const API_CONFIG = {
  // HTTP API 基础 URL
  BASE_URL: API_BASE_URL,

  // WebSocket 基础 URL
  WS_BASE_URL: WS_BASE_URL,

  // HTTP 服务器地址（不含 /api）
  HTTP_SERVER: getHttpBaseUrl(),

  // WebSocket 服务器地址（不含 /api）
  WS_SERVER: getWsBaseUrl(),

  // 完整的 WebSocket 端点
  WS_ENDPOINTS: {
    TERMINAL: `${WS_BASE_URL}/terminal/ws`,
    EXECUTION: `${WS_BASE_URL}/executions/ws`,
  },
};

// 导出便捷函数
export const getApiUrl = (path: string) => {
  return `${API_CONFIG.BASE_URL}${path}`;
};

export const getWsUrl = (path: string) => {
  return `${API_CONFIG.WS_BASE_URL}${path}`;
};
